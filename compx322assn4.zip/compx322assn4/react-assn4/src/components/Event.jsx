import React from 'react'; // Import React

// Define the Event functional component
function Event({ event, onDelete }) {
  return (
    <div className="event">
      <h3>{event.name}</h3> {/* Display the event name */}
      <p>{event.description}</p> {/* Display the event description */}
      <p>Start Date: {event.startDate}</p> {/* Display the event start date */}
      <p>End Date: {event.endDate}</p> {/* Display the event end date */}
      <button onClick={() => onDelete(event.id)}>Delete</button> {/* Button to delete the event, calling onDelete with the event ID */}
    </div>
  );
}

export default Event; // Export the Event component as the default export
