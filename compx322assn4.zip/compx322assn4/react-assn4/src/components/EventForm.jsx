import React, { useState } from 'react'; // Import React and the useState hook

// Define the EventForm functional component
function EventForm({ onAdd }) {
  // State variables to hold the form input values
  const [name, setName] = useState(''); // State for the event name
  const [description, setDescription] = useState(''); // State for the event description
  const [startDate, setStartDate] = useState(''); // State for the event start date
  const [endDate, setEndDate] = useState(''); // State for the event end date

  // Function to handle form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the default form submission behavior
    onAdd({ name, description, startDate, endDate }); // Call the onAdd function passed as a prop with the form data
    setName(''); // Reset the name state to an empty string
    setDescription(''); // Reset the description state to an empty string
    setStartDate(''); // Reset the startDate state to an empty string
    setEndDate(''); // Reset the endDate state to an empty string
  };

  // JSX to render the form
  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Event Name"
        value={name}
        onChange={(e) => setName(e.target.value)} // Update the name state when the input value changes
        required
      />
      <textarea
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)} // Update the description state when the textarea value changes
        required
      ></textarea>
      <input
        type="date"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)} // Update the startDate state when the input value changes
        required
      />
      <input
        type="date"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)} // Update the endDate state when the input value changes
        required
      />
      <button type="submit">Add Event</button> {/* Submit button to add the event */}
    </form>
  );
}

export default EventForm; // Export the EventForm component as the default export
