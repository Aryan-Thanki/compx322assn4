import React from 'react'; // Import React
import Event from './Event'; // Import the Event component

// Define the EventList functional component
function EventList({ events, onDelete }) {
  return (
    <div className="event-list">
      {events.map(event => (
        // For each event in the events array, render an Event component
        // Pass the event object and onDelete function as props
        <Event key={event.id} event={event} onDelete={onDelete} />
      ))}
    </div>
  );
}

export default EventList; // Export the EventList component as the default export
