import axios from 'axios'; // Import axios for making HTTP requests
import React, { useEffect, useState } from 'react';
import EventForm from '../components/EventForm'; // Import the EventForm component from the components directory
import EventList from '../components/EventList'; // Import the EventList component from the components directory

function App() {
  // State variables
  const [events, setEvents] = useState([]); // State to hold the list of events
  const [search, setSearch] = useState(''); // State to hold the search query
  const [sortOrder, setSortOrder] = useState('asc'); // State to hold the sort order (ascending or descending)

  // useEffect to fetch events from the API when the component mounts
  useEffect(() => {
    axios.get('http://localhost:3000/events').then(response => setEvents(response.data)).catch(error => console.error("Error fetching events: ", error)); //On success, update the events state with the fetched data. Log any errors that occur during the request
  }, []); // Empty dependency array means this effect runs only once after the initial render

  // Function to add a new event
  const addEvent = (event) => {
    axios.post('http://localhost:3000/events', event).then(response => setEvents([...events, response.data])).catch(error => console.error("Error adding event: ", error)); // On success, add the new event to the events state. Log any errors that occur during the request
  };

  // Function to delete an event by its ID
  const deleteEvent = (id) => {
    axios.delete(`http://localhost:3000/events/${id}`).then(() => setEvents(events.filter(event => event.id !== id))).catch(error => console.error("Error deleting event: ", error)); //On success, remove the event from the events state. Log any errors that occur during the request
  };

  // Filter the events based on the search query
  const filteredEvents = events.filter(event => event.name.toLowerCase().includes(search.toLowerCase()));

  // Sort the filtered events based on the sort order and start date
  const sortedEvents = filteredEvents.sort((a, b) => sortOrder === 'asc' ? new Date(a.startDate) - new Date(b.startDate) : new Date(b.startDate) - new Date(a.startDate));

  // JSX to render the UI
  return (
    <div className="app">
      <h1>Event Management Application</h1>
      <input
        type="text"
        placeholder="Search events"
        value={search}
        onChange={(e) => setSearch(e.target.value)} // Update the search state when the input value changes
      />
      <button onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}>Sort by Date</button> {/* Toggle sort order between ascending and descending */}
      <EventForm onAdd={addEvent} /> {/* Pass the addEvent function to the EventForm component */}
      <EventList events={sortedEvents} onDelete={deleteEvent} /> {/* Pass the sorted events and deleteEvent function to the EventList component */}
    </div>
  );
}

export default App; // Export the App component as the default export
